"use client"

import { useState } from "react"
import { ArrowLeft, Users, Eye, MessageCircle, Heart, TrendingUp, Calendar, Play, ExternalLink } from 'lucide-react'
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

// Mock data for channel details
const channelData = {
  id: "1",
  name: "TechReview Pro",
  handle: "@techreviewpro",
  subscribers: 2500000,
  avatar: "/placeholder.svg?height=80&width=80&text=TR",
  description: "Professional tech reviews and tutorials for the modern world",
  joinedDate: "2019-03-15",
  totalVideos: 342,
  totalViews: 125000000,
  totalComments: 2500000,
  totalLikes: 8500000
}

// Mock trending data
const trendData = [
  { date: "2024-01-01", views: 450000, comments: 12000, likes: 35000 },
  { date: "2024-01-02", views: 520000, comments: 15000, likes: 42000 },
  { date: "2024-01-03", views: 380000, comments: 9000, likes: 28000 },
  { date: "2024-01-04", views: 680000, comments: 18000, likes: 55000 },
  { date: "2024-01-05", views: 720000, comments: 22000, likes: 68000 },
  { date: "2024-01-06", views: 590000, comments: 16000, likes: 48000 },
  { date: "2024-01-07", views: 820000, comments: 25000, likes: 75000 }
]

// Mock top performing videos
const topVideos = [
  {
    id: "1",
    title: "iPhone 15 Pro Max - Complete Review After 3 Months",
    thumbnail: "/placeholder.svg?height=90&width=160&text=iPhone",
    views: 2800000,
    comments: 45000,
    likes: 180000,
    publishedAt: "2024-01-15",
    duration: "18:42",
    engagement: 225000
  },
  {
    id: "2", 
    title: "M3 MacBook Pro vs M2 - The Ultimate Comparison",
    thumbnail: "/placeholder.svg?height=90&width=160&text=MacBook",
    views: 1950000,
    comments: 32000,
    likes: 125000,
    publishedAt: "2024-01-10",
    duration: "22:15",
    engagement: 157000
  },
  {
    id: "3",
    title: "Best Budget Smartphones 2024 - Top 10 Picks",
    thumbnail: "/placeholder.svg?height=90&width=160&text=Budget",
    views: 1650000,
    comments: 28000,
    likes: 95000,
    publishedAt: "2024-01-05",
    duration: "15:30",
    engagement: 123000
  }
]

// Mock viral videos (5x more views than subscribers)
const viralVideos = [
  {
    id: "4",
    title: "This Phone Feature Will Blow Your Mind!",
    thumbnail: "/placeholder.svg?height=90&width=160&text=Viral",
    views: 15200000,
    comments: 125000,
    likes: 850000,
    publishedAt: "2023-12-20",
    duration: "8:45",
    engagement: 975000,
    viralMultiplier: 6.08
  },
  {
    id: "5",
    title: "I Bought Every iPhone Ever Made",
    thumbnail: "/placeholder.svg?height=90&width=160&text=iPhones",
    views: 12800000,
    comments: 98000,
    likes: 720000,
    publishedAt: "2023-11-15",
    duration: "25:12",
    engagement: 818000,
    viralMultiplier: 5.12
  }
]

// Mock recent videos (past 120 days)
const recentVideos = [
  ...topVideos,
  {
    id: "6",
    title: "Samsung Galaxy S24 Ultra First Look",
    thumbnail: "/placeholder.svg?height=90&width=160&text=Galaxy",
    views: 1200000,
    comments: 18000,
    likes: 75000,
    publishedAt: "2024-01-20",
    duration: "12:30",
    engagement: 93000
  },
  {
    id: "7",
    title: "AirPods Pro 3 - Everything We Know",
    thumbnail: "/placeholder.svg?height=90&width=160&text=AirPods",
    views: 890000,
    comments: 12000,
    likes: 52000,
    publishedAt: "2024-01-18",
    duration: "9:15",
    engagement: 64000
  }
].sort((a, b) => b.engagement - a.engagement)

export default function ChannelDashboard({ params }: { params: { id: string } }) {
  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`
    return num.toString()
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    })
  }

  const calculateEngagement = (views: number, comments: number, likes: number) => {
    return comments + likes
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="mb-6">
          <Link href="/">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Channels
            </Button>
          </Link>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-start gap-6">
                <Avatar className="h-20 w-20">
                  <AvatarImage src={channelData.avatar || "/placeholder.svg"} alt={channelData.name} />
                  <AvatarFallback className="text-2xl">{channelData.name.slice(0, 2)}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h1 className="text-3xl font-bold mb-2">{channelData.name}</h1>
                  <p className="text-muted-foreground mb-4">{channelData.handle}</p>
                  <p className="text-sm text-muted-foreground mb-4">{channelData.description}</p>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <span className="font-semibold">{formatNumber(channelData.subscribers)}</span>
                      <span className="text-sm text-muted-foreground">subscribers</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Play className="h-4 w-4 text-muted-foreground" />
                      <span className="font-semibold">{channelData.totalVideos}</span>
                      <span className="text-sm text-muted-foreground">videos</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Eye className="h-4 w-4 text-muted-foreground" />
                      <span className="font-semibold">{formatNumber(channelData.totalViews)}</span>
                      <span className="text-sm text-muted-foreground">total views</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">Joined {formatDate(channelData.joinedDate)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Analytics Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="viral">Viral Videos</TabsTrigger>
            <TabsTrigger value="recent">Recent (120d)</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Top Performing Videos */}
            <Card>
              <CardHeader>
                <CardTitle>Top Performing Videos</CardTitle>
                <CardDescription>Videos with highest engagement scores</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {topVideos.map((video, index) => (
                    <div key={video.id} className="flex items-center gap-4 p-4 border rounded-lg">
                      <div className="flex items-center justify-center w-8 h-8 bg-primary text-primary-foreground rounded-full text-sm font-bold">
                        {index + 1}
                      </div>
                      <img 
                        src={video.thumbnail || "/placeholder.svg"} 
                        alt={video.title}
                        className="w-24 h-14 object-cover rounded"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold line-clamp-2">{video.title}</h3>
                        <p className="text-sm text-muted-foreground">{formatDate(video.publishedAt)} • {video.duration}</p>
                      </div>
                      <div className="text-right space-y-1">
                        <div className="flex items-center gap-4 text-sm">
                          <div className="flex items-center gap-1">
                            <Eye className="h-3 w-3" />
                            {formatNumber(video.views)}
                          </div>
                          <div className="flex items-center gap-1">
                            <MessageCircle className="h-3 w-3" />
                            {formatNumber(video.comments)}
                          </div>
                          <div className="flex items-center gap-1">
                            <Heart className="h-3 w-3" />
                            {formatNumber(video.likes)}
                          </div>
                        </div>
                        <Badge variant="secondary">
                          {formatNumber(video.engagement)} engagement
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="viral" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Viral Videos</CardTitle>
                <CardDescription>Videos with 5x+ more views than subscriber count</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {viralVideos.map((video, index) => (
                    <div key={video.id} className="flex items-center gap-4 p-4 border rounded-lg bg-gradient-to-r from-orange-50 to-red-50 dark:from-orange-950/20 dark:to-red-950/20">
                      <div className="flex items-center justify-center w-8 h-8 bg-orange-500 text-white rounded-full text-sm font-bold">
                        🔥
                      </div>
                      <img 
                        src={video.thumbnail || "/placeholder.svg"} 
                        alt={video.title}
                        className="w-24 h-14 object-cover rounded"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold line-clamp-2">{video.title}</h3>
                        <p className="text-sm text-muted-foreground">{formatDate(video.publishedAt)} • {video.duration}</p>
                        <Badge variant="destructive" className="mt-1">
                          {video.viralMultiplier.toFixed(1)}x viral multiplier
                        </Badge>
                      </div>
                      <div className="text-right space-y-1">
                        <div className="flex items-center gap-4 text-sm">
                          <div className="flex items-center gap-1">
                            <Eye className="h-3 w-3" />
                            {formatNumber(video.views)}
                          </div>
                          <div className="flex items-center gap-1">
                            <MessageCircle className="h-3 w-3" />
                            {formatNumber(video.comments)}
                          </div>
                          <div className="flex items-center gap-1">
                            <Heart className="h-3 w-3" />
                            {formatNumber(video.likes)}
                          </div>
                        </div>
                        <Badge variant="secondary">
                          {formatNumber(video.engagement)} engagement
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="recent" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Videos (Past 120 Days)</CardTitle>
                <CardDescription>All videos from the last 4 months, ordered by engagement</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Video</TableHead>
                      <TableHead>Published</TableHead>
                      <TableHead>Views</TableHead>
                      <TableHead>Comments</TableHead>
                      <TableHead>Likes</TableHead>
                      <TableHead>Engagement</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentVideos.map((video) => (
                      <TableRow key={video.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <img 
                              src={video.thumbnail || "/placeholder.svg"} 
                              alt={video.title}
                              className="w-16 h-9 object-cover rounded"
                            />
                            <div>
                              <p className="font-medium line-clamp-2 max-w-xs">{video.title}</p>
                              <p className="text-sm text-muted-foreground">{video.duration}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{formatDate(video.publishedAt)}</TableCell>
                        <TableCell>{formatNumber(video.views)}</TableCell>
                        <TableCell>{formatNumber(video.comments)}</TableCell>
                        <TableCell>{formatNumber(video.likes)}</TableCell>
                        <TableCell>
                          <Badge variant="secondary">
                            {formatNumber(video.engagement)}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
